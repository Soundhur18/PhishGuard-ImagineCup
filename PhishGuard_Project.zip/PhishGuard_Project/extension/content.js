// Utility: Debounce function to limit API calls
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Create a toast element for notifications
const toast = document.createElement("div");
toast.id = "phishguard-toast";
toast.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #333;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    font-family: 'Segoe UI', sans-serif;
    font-size: 14px;
    z-index: 10000;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    display: none;
    max-width: 300px;
    transition: opacity 0.3s ease-in-out;
    opacity: 0;
`;
document.body.appendChild(toast);

const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playBeep() {
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.type = 'square';
    osc.frequency.setValueAtTime(200, audioCtx.currentTime);
    osc.frequency.linearRampToValueAtTime(100, audioCtx.currentTime + 0.15); // Drop tone (error sound)

    gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.15);

    osc.start();
    osc.stop(audioCtx.currentTime + 0.15);
}

function showToast(message, isDanger = false) {
    if (isDanger) playBeep(); // Audio Alert

    toast.textContent = message;
    toast.style.backgroundColor = isDanger ? "#d93025" : "#1e8e3e"; // Red for danger, Green for safe
    toast.style.display = "block";
    // Force reflow for transition
    void toast.offsetWidth;
    toast.style.opacity = "1";

    setTimeout(() => {
        toast.style.opacity = "0";
        setTimeout(() => {
            toast.style.display = "none";
        }, 300);
    }, 5000);
}

// Scan function (debounced)
const handleLinkHover = debounce((event) => {
    const link = event.target.closest('a');
    if (!link) return;

    const linkData = {
        text: link.innerText,
        href: link.href
    };

    // Send both text and url to be robust for the AI
    chrome.runtime.sendMessage({ action: "analyze", text: linkData.href, url: linkData.href }, (response) => {
        // Remove Scanning state
        link.classList.remove('phishguard-active-scan');

        if (response && response.result) {
            const aiData = response.result;
            // console.log("PhishGuard Analysis:", aiData);

            if (aiData.is_phishing) {
                // Apply the DANGER style
                link.classList.add('phishguard-highlight-danger');
                showToast(`⚠️ Danger: ${aiData.reason}`, true);
            } else {
                // Apply the SAFE style
                link.classList.add('phishguard-highlight-safe');
            }
        }
    });
}, 500);

// Listener for mouseover
document.addEventListener('mouseover', (event) => {
    const link = event.target.closest('a');
    if (link) {
        // Instant visual feedback for judges (Scanning State)
        link.classList.add('phishguard-active-scan');

        // Trigger the backend scan specifically for this URL
        handleLinkHover(event);
    }
});

document.addEventListener('mouseout', (event) => {
    const link = event.target.closest('a');
    if (link) {
        link.classList.remove('phishguard-active-scan');
        link.classList.remove('phishguard-highlight-danger');
        link.classList.remove('phishguard-highlight-safe');
    }
});

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "get_page_text") {
        // Extract up to 30 unsafe links for analysis
        const links = Array.from(document.querySelectorAll('a[href]'))
            .map(a => a.href)
            .filter(href => href.startsWith('http'))
            .slice(0, 30);

        sendResponse({
            text: document.body.innerText.substring(0, 5000), // Limit text
            links: links
        });
    }
    return true;
});
