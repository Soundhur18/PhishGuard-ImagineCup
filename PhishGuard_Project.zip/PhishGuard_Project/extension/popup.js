document.addEventListener('DOMContentLoaded', function () {
    const scanBtn = document.getElementById('scan-btn');
    const verdictDisplay = document.getElementById('page-verdict');
    const statusCard = document.getElementById('status-card');
    const statusIcon = document.getElementById('status-icon');
    const detailsBox = document.getElementById('analysis-details');
    const reasonText = document.getElementById('reason-text');
    const btnText = scanBtn.querySelector("span");

    // Helper to set UI state
    function setUIState(state, message = "") {
        // Reset classes
        statusCard.classList.remove('safe', 'danger');

        if (state === 'loading') {
            scanBtn.disabled = true;
            btnText.textContent = "Analyzing...";
            // Add spinner if not present
            if (!scanBtn.querySelector('.spinner')) {
                const spinner = document.createElement('div');
                spinner.className = 'spinner';
                scanBtn.insertBefore(spinner, btnText);
            }
            verdictDisplay.innerText = "Scanning Page...";
            statusIcon.innerText = "🔍";
            detailsBox.style.display = "none";
        } else {
            scanBtn.disabled = false;
            btnText.textContent = "Scan Full Page";
            const spinner = scanBtn.querySelector('.spinner');
            if (spinner) spinner.remove();
        }

        if (state === 'safe') {
            statusCard.classList.add('safe');
            statusIcon.innerText = "✅";
            verdictDisplay.innerText = "Page Seems Safe";
        } else if (state === 'danger') {
            statusCard.classList.add('danger');
            statusIcon.innerText = "⚠️";
            verdictDisplay.innerText = "Phishing Detected";
        } else if (state === 'error') {
            statusIcon.innerText = "❓";
            verdictDisplay.innerText = message || "Analysis Failed";
        }
    }

    // When the user clicks the button, ask the current tab for its content
    scanBtn.addEventListener('click', async () => {
        setUIState('loading');

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (!tab) {
            setUIState('error', "No active tab found");
            return;
        }

        // Step 1: Get text from Content Script
        chrome.tabs.sendMessage(tab.id, { action: "get_page_text" }, (response) => {
            if (chrome.runtime.lastError || !response) {
                console.error("Runtime error:", chrome.runtime.lastError);
                setUIState('error', "Please refresh the page!");
                return;
            }

            const dataForAI = {
                url: tab.url,        // The actual address bar URL
                text: response.text, // The sanitized text
                links: response.links // Array of links found on page
            };

            // Step 2: Send text to Service Worker for Analysis
            chrome.runtime.sendMessage({ action: "analyze", ...dataForAI }, (aiResponse) => {
                if (aiResponse && aiResponse.result) {
                    const aiData = aiResponse.result;
                    reasonText.innerText = aiData.reason || "No detail provided.";
                    detailsBox.style.display = "block";

                    if (aiData.is_phishing) {
                        setUIState('danger');
                    } else {
                        setUIState('safe');
                    }
                } else {
                    setUIState('error', "Server error or offline.");
                }
            });
        });
    });
});
