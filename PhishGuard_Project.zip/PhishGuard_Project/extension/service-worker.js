chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "analyze") {
        fetch("http://localhost:3000/analyze", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: request.text, url: request.url })
        })
            .then(res => res.json())
            .then(data => {
                // data is { result: { is_phishing... } } from backend
                // popup expects aiResponse.result to be { is_phishing ... }
                // So we send { result: data.result }
                if (data.result) {
                    sendResponse({ result: data.result });
                } else {
                    // Fallback if structure is different
                    sendResponse({ result: data });
                }
            })
            .catch(err => {
                console.error("Fetch Error:", err);
                sendResponse({ result: { is_phishing: false, reason: "Localhost server unreachable." } });
            });
        return true; // Keeps the channel open for the async fetch
    }
});

const scannedUrls = new Set();
const whitelist = ['google.com', 'github.com', 'localhost'];

// 1. Listen for URL changes
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // Only scan when the page is fully loaded and has a valid URL
    if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
        startRealTimeScan(tabId, tab.url);
    }
});

async function startRealTimeScan(tabId, url) {
    // 1. Cache Check
    if (scannedUrls.has(url)) return;

    // 2. Whitelist Check
    try {
        const domain = new URL(url).hostname;
        if (whitelist.some(d => domain.includes(d))) return;
    } catch (e) {
        // Invalid URL, skip
        return;
    }

    // Mark as scanned
    scannedUrls.add(url);

    try {
        // 3. Ask the Content Script for page text
        const response = await chrome.tabs.sendMessage(tabId, { action: "get_page_text" });

        if (response && response.text) {
            // 3. Send to your local AI server
            const aiResponse = await fetch("http://localhost:3000/analyze", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ url: url, text: response.text })
            });

            const data = await aiResponse.json();
            // Correctly access the nested result object from backend
            const aiResult = data.result || data;

            // 4. Alert the user if phishing is found
            if (aiResult.is_phishing) {
                // Check if the user already bypassed this scan
                if (url.includes("phishguard_bypass=true")) return;

                const warningUrl = chrome.runtime.getURL("warning.html") +
                    `?url=${encodeURIComponent(url)}&reason=${encodeURIComponent(aiResult.reason)}&confidence=${aiResult.confidence || 0}`;

                chrome.tabs.update(tabId, { url: warningUrl });
            }
        }
    } catch (err) {
        // This is normal for pages where content script isn't injected (e.g. chrome://)
        // console.log("Scan skipped:", err); 
    }
}

function notifyUser(reason) {
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icon48.png', // Ensure you have this icon
        title: 'PhishGuard Alert!',
        message: reason,
        priority: 2
    });
}
