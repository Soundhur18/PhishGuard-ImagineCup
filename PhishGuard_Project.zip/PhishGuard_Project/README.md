# 🛡️ PhishGuard - AI-Powered Anti-Phishing Defense
### Imagine Cup 2026 Submission

![PhishGuard Banner](https://via.placeholder.com/1200x300/0078d4/ffffff?text=PhishGuard+AI+Protection)

**PhishGuard** is a next-generation browser extension that uses **Real-Time AI Analysis** to detect and block zero-day phishing attacks, typosquatting, and social engineering attempts that traditional blacklists miss.

---

## 🚀 Key Features

### 1. 🧠 Real-Time AI Analysis (Azure OpenAI)
PhishGuard doesn't just check accurate blacklists; it **reads the page content** like a human security analyst.
- **Deep Scan**: Analyzes page text, context, and *all embedded links* for malicious intent.
- **Zero-Lag**: Uses a **Smart Server-Side Cache** (1-Hour TTL) to provide instant feedback for known URLs.

### 2. ⚡ "Zero-Latency" UX
- **Instant Visuals**: Hover over any link to see an immediate "Scanning" indicator (Amber dashed line).
- **Live Verdicts**: Links turn **Green** (Safe) or **Red** (Danger) dynamically based on AI scoring.

### 3. 📉 Live SOC Dashboard
A professional **Security Operations Center (SOC)** dashboard for enterprise admins.
- **Real-Time Data**: Uses **WebSockets (Socket.io)** to stream scan results instantly.
- **Analytics**: Live Chart.js visualization of Safe vs. Threat traffic.

### 4. 🚨 educational Warning Interruption
When a user navigates to a dangerous site, PhishGuard intercepts the request and displays a **Professional Warning Page** explaining *exactly why* the site is dangerous (e.g., "Credential Harvesting detected").

---

## 🛠️ Tech Stack

- **Frontend**: Chrome Extension (Manifest V3), HTML5, CSS3, Vanilla JS.
- **Backend**: Node.js, Express.js.
- **AI Engine**: Azure OpenAI (GPT-4o).
- **Database**: MongoDB (Mongoose) for Logs & Reports.
- **Real-Time**: Socket.io (WebSockets).
- **Visualization**: Chart.js.

---

## 📦 Installation & Setup

### Prerequisites
- Node.js (v18+)
- MongoDB (Local or Atlas)
- Chrome Browser

### 1. Clone & Install
```bash
git clone https://github.com/username/PhishGuard.git
cd PhishGuard_Project
```

### 2. Backend Setup
```bash
cd backend
npm install
# Create a .env file with:
# AZURE_OPENAI_ENDPOINT=...
# AZURE_OPENAI_API_KEY=...
# MONGODB_URI=mongodb://127.0.0.1:27017/phishguard
node server.js
```

### 3. Extension Setup
1. Open Chrome and navigate to `chrome://extensions`.
2. Enable **Developer Mode** (top right).
3. Click **Load unpacked**.
4. Select the `extension` folder from this project.

### 4. Run the Demo
1. Open `tests/demo.html` in Chrome.
2. Open `frontend/dashboard.html` in another window (to see live analytics).
3. Hover over the "Login to PayPal" link to see PhishGuard in action!

---

## 📸 Screenshots

| Warning Page | SOC Dashboard |
|---|---|
| *(Screenshot of Warning Page)* | *(Screenshot of Dashboard)* |

---
*Built with ❤️ for a Safer Web.*
