const mongoose = require('mongoose');

// Connect to the same DB
mongoose.connect('mongodb://127.0.0.1:27017/phishguard')
    .then(async () => {
        console.log("Connected to MongoDB for debugging...");

        // Define same schema to query
        const Report = mongoose.model('Report', new mongoose.Schema({
            url: String,
            type: String,
            reason: String,
            timestamp: Date
        }));

        try {
            const count = await Report.countDocuments();
            console.log(`Total Reports found: ${count}`);

            const docs = await Report.find();
            console.log("Reports:", JSON.stringify(docs, null, 2));
        } catch (err) {
            console.error("Query Error:", err);
        } finally {
            mongoose.disconnect();
        }
    })
    .catch(err => console.error("Connection Error:", err));
