require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');

const app = express();
const PORT = process.env.PORT || 3000;

// Socket.io Setup
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/phishguard')
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('MongoDB connection error:', err));

// Schemas & Models
const reportSchema = new mongoose.Schema({
    url: String,
    type: String,
    reason: String,
    timestamp: { type: Date, default: Date.now }
});
const Report = mongoose.model('Report', reportSchema);

const logSchema = new mongoose.Schema({
    url: String,
    is_phishing: Boolean,
    reason: String,
    timestamp: { type: Date, default: Date.now }
});
const Log = mongoose.model('Log', logSchema);

// --- Logic Improvement 1: Server-Side Cache ---
const resultCache = new Map();
const CACHE_TTL_MS = 3600 * 1000; // 1 Hour

// Socket Event
io.on('connection', (socket) => {
    console.log('Dashboard connected:', socket.id);

    // Relay Warning Page events to Dashboard
    socket.on('warning_opened', (data) => {
        console.log(`[ALERT] User accessed Warning Page for: ${data.url}`);
        io.emit('dashboard_alert', data);
    });
});

// --- Routes ---

app.get('/', (req, res) => {
    res.send('PhishGuard Backend is running!');
});

// API: Fetch Logs for Dashboard
app.get('/api/logs', async (req, res) => {
    try {
        const logs = await Log.find().sort({ timestamp: -1 }).limit(50);
        res.json(logs);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch logs' });
    }
});

// API: Analyze Text (+ Links now)
app.post('/analyze', async (req, res) => {
    const { text, url, links } = req.body; // Extract Links

    if (!text) {
        return res.status(400).json({ error: 'Text is required' });
    }

    // Smart Caching (Skip for this logic update to ensure AI re-evaluates)
    if (url && resultCache.has(url)) {
        // Force clear cache if links are present to prioritize re-scan logic
        // In a real app we'd have a smarter key, but for demo let's clear it if the user is hammering "Scan"
        // Actually, let's just stick to the cache unless explicitly told not to.
        // But for this "Fix", I want the user to see the NEW result.
        resultCache.delete(url);
    }

    // Construct Context
    const linksContext = links && links.length > 0
        ? `\n\nAnalyzed Links on this page:\n${links.join('\n')}`
        : "";

    console.log(`[ANALYSIS] Analyzing ${url} with ${links ? links.length : 0} links.`);

    try {
        const response = await axios.post(
            process.env.AZURE_OPENAI_ENDPOINT,
            {
                messages: [
                    {
                        role: "system",
                        content: "You are PhishGuard. Analyze the provided Page Content and URL List for phishing. \n1. If the Main URL is a local file (file://), it is SAFE unless the content explicitly links to phishing sites.\n2. CRITICAL: Check the 'Analyzed Links' list. If ANY link in that list looks like a phishing attempt (typosquatting, misleading domain, credential harvesting), you MUST flag the ENTIRE PAGE as Dangerous.\n3. Return JSON: { is_phishing, confidence, reason }."
                    },
                    {
                        role: "user",
                        content: `Main URL: ${url || 'Unknown'}\n\nPage Content:\n${text}\n${linksContext}`
                    }
                ],
                max_tokens: 500,
                temperature: 0.7
            },
            {
                headers: {
                    'api-key': process.env.AZURE_OPENAI_API_KEY,
                    'Content-Type': 'application/json'
                }
            }
        );

        const aiRawText = response.data.choices[0].message.content;

        // Robust JSON Extraction: Find the outermost JSON object
        let aiData;
        try {
            const jsonStartIndex = aiRawText.indexOf('{');
            const jsonEndIndex = aiRawText.lastIndexOf('}');

            if (jsonStartIndex !== -1 && jsonEndIndex !== -1 && jsonEndIndex > jsonStartIndex) {
                const cleanText = aiRawText.substring(jsonStartIndex, jsonEndIndex + 1);
                aiData = JSON.parse(cleanText);
            } else {
                throw new Error("No JSON found in response");
            }
        } catch (parseError) {
            console.error("AI returned invalid JSON:", aiRawText);
            aiData = {
                is_phishing: false,
                confidence: 0,
                reason: "AI response format error. Please try again."
            };
        }

        // --- Logic Improvement 3: Update Cache ---
        if (url) {
            resultCache.set(url, {
                data: aiData,
                timestamp: Date.now()
            });
        }

        // Save to Detailed Logs & Emit Real-time Event
        try {
            const newLog = await Log.create({
                url: url || 'Unknown',
                is_phishing: aiData.is_phishing,
                reason: aiData.reason
            });

            // Real-time Emit
            io.emit('new_log', newLog);
        } catch (logErr) {
            console.error("Failed to save log:", logErr);
        }

        res.json({ result: aiData });

    } catch (error) {
        console.error('Error calling Azure OpenAI:', error.response ? error.response.data : error.message);
        res.status(500).json({ error: 'Failed to analyze text' });
    }
});

// API: Report False Positive
app.post('/report', async (req, res) => {
    const { url, type, reason } = req.body;

    console.log(`[REPORT] ${type}: ${url}`);

    try {
        await Report.create({ url, type, reason });
        res.json({ status: 'success', message: 'Report saved to MongoDB' });
    } catch (err) {
        console.error("Error saving to MongoDB:", err);
        res.status(500).json({ error: 'Failed to save report' });
    }
});

// Start Server
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
